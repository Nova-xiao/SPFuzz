#!/bin/bash

DURATION=30
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &
# timeout -s SIGINT -k 10s ${DURATION}s `pwd`/StressTesting/stress  &